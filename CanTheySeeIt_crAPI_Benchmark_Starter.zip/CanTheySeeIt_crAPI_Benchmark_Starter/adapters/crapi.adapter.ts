import type { TargetAdapter } from '../src/adapter.ts';
import type { TestCase } from '../src/contracts.ts';

/**
 * Phase 0: intentionally NOT registered. No API routes or fixture IDs are guessed.
 * Replace these placeholders only after a locally installed OWASP crAPI instance
 * has been reviewed and its legitimate user/ownership flows confirmed.
 */
const notReady = (): never => {
  throw new Error('NEEDS_SETUP: verify crAPI API contracts, two disposable identities, and owned fixtures first');
};

export function createCrapiAdapter(): TargetAdapter {
  return {
    id: 'crapi-local-benchmark',
    baseUrl: 'http://127.0.0.1:8888/',
    syntheticOnly: true,
    fixtureRevision: 'UNCONFIGURED',
    approvedPaths: new Set<string>(),
    async ready() { return { ready: false, reason: 'CRAPI_ADAPTER_NOT_CONFIGURED' }; },
    async validateActor(_actorRef: string) { return notReady(); },
    async authHeaders(_actorRef: string) { return notReady(); },
    async resolve(_test: TestCase): Promise<{path: string; method: 'GET' | 'PATCH'; body?: unknown}> { return notReady(); },
    matchesProtectedFixture(_test: TestCase, _body: unknown) { return notReady(); },
    async snapshot(_test: TestCase) { return notReady(); },
    compareState(_test: TestCase, _before: unknown, _after: unknown) { return notReady(); },
    async restore(_test: TestCase, _original: unknown) { return notReady(); }
  };
}
